<?php

    $emp="select * from employee order by employee_id";
    $customer="select * from customer order by customer_id";
    $dealer="select * from dealer order by dealer_id";
//    $serves="select * from serves_for order by air_name";
//    $bag="select * from baggage order by bag_id";
//    $carries="select * from carries order by passport_no,nation";
//    $cab="select * from cab order by cab_id";
//    $rent="select * from rents order by passport_no, nation";
//    $cur="select * from currency order by exchange_date, exchange_serial";
//    $ex="select * from exchanges order by passport_no,nation";
//    $flt="select * from flight order by flight_no";
//    $fuel="select * from fuel order by refill_date, refill_serial";
//    $refill="select * from refills order by flight_no";
//    $gate="select * from gate order by gate_no";
//    $wt="select * from waits_at order by passport_no, nation";
//    $assn="select * from is_assigned_to order by flight_no";
//    $hangar="select * from hangar order by hangar_no";
//    $halt="select * from halts_in order by flight_no";
//    $mntn="select * from maintains order by e_id";

    switch($_POST['show']){
        case "employee"         :       $stmt=$emp; break;
        case "customer"     :       $stmt=$customer; break;
        case "dealer"          :       $stmt=$dealer; break;
//        case "currency"              :       $stmt=$cur; break;
//        case "flight"              :       $stmt=$flt; break;
//        case "fuel"              :       $stmt=$fuel; break;
//        case "gate"              :       $stmt=$gate; break;
//        case "hangar"              :       $stmt=$hangar; break;
//        case "airline"              :       $stmt=$air; break;
    }

    if ($_POST['Submit']=="Show List"){
        $conn=oci_connect("system","mM18061996","localhost/xe");
        $stid=oci_parse($conn,$stmt);
        oci_execute($stid);

        echo "<table border='1'>\n";
        $ncols = oci_num_fields($stid);
        echo "</tr>";
        for ($i = 1; $i <= $ncols; $i++) {
            $column_name  = oci_field_name($stid, $i);

            echo "<th>$column_name</th>";
        }
        while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
            echo "<tr>\n";
            foreach ($row as $item) {
                echo "    <td>" . ($item !== null ? htmlentities($item, ENT_QUOTES) : "&nbsp;") . "</td>\n";
            }
            echo "</tr>\n";
        }
        echo "</table>\n";
    }

?>

