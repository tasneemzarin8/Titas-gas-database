<?php

    $conn=oci_connect("system","mM18061996","localhost/xe");

    if (isset($_POST['insrt'])){

        $CUSTOMER_ID=htmlspecialchars($_POST['CUSTOMER_ID']);
        $CUSTOMER_NAME=htmlspecialchars($_POST['CUSTOMER_NAME']);
        $CUSTOMER_USER_NAME=htmlspecialchars($_POST['CUSTOMER_USER_NAME']);
        $CUSTOMER_PASSWORD=htmlspecialchars($_POST['CUSTOMER_PASSWORD']);
        $CUSTOMER_TOTAL_METER=htmlspecialchars($_POST['CUSTOMER_TOTAL_METER']);
        $DATE_OF_CONNECTION=htmlspecialchars(date('d.m.Y', strtotime($_POST['DATE_OF_CONNECTION'])));       
        $DATE_OF_DISCONNECTION=htmlspecialchars(date('d.m.Y', strtotime($_POST['DATE_OF_DISCONNECTION'])));       
        $ROAD_NO=htmlspecialchars($_POST['ROAD_NO']);
        $STREET_NO=htmlspecialchars($_POST['STREET_NO']);
        $HOUSE_NO=htmlspecialchars($_POST['HOUSE_NO']);


        $conn=oci_connect("system","mM18061996","localhost/xe");
        $stmt= "insert into TITASP.customer values (:CUSTOMER_ID, :CUSTOMER_NAME, :CUSTOMER_TOTAL_METER,TO_DATE('".$DATE_OF_CONNECTION."','DD.MM.YYYY'),TO_DATE('".$DATE_OF_DISCONNECTION."','DD.MM.YYYY'),:CUSTOMER_USER_NAME, :ROAD_NO, :STREET_NO, :HOUSE_NO ,:CUSTOMER_PASSWORD)";
        $stid=oci_parse($conn,$stmt);

        oci_bind_by_name($stid, ':CUSTOMER_ID', $CUSTOMER_ID);
        oci_bind_by_name($stid, ':CUSTOMER_NAME', $CUSTOMER_NAME);
        oci_bind_by_name($stid, ':CUSTOMER_TOTAL_METER', $CUSTOMER_TOTAL_METER);
        oci_bind_by_name($stid, ':CUSTOMER_USER_NAME', $CUSTOMER_USER_NAME);
        oci_bind_by_name($stid, ':ROAD_NO', $ROAD_NO);
        oci_bind_by_name($stid, ':STREET_NO', $STREET_NO);
        oci_bind_by_name($stid, ':HOUSE_NO', $HOUSE_NO);
        oci_bind_by_name($stid, ':CUSTOMER_PASSWORD', $CUSTOMER_PASSWORD);

        if (oci_execute($stid))

        { echo "Inserted!\n";
        echo  "<a href=\"customer.php\">Go Back</a>";}
else{         header("Location: http://localhost/titas/admin/insertion/customer/wrong.php");

    }
    
    }


    if(isset($_POST['updt'])){
        $CUSTOMER_ID=htmlspecialchars($_POST['CUSTOMER_ID']);
        $new=htmlspecialchars($_POST['new']);
        if ($_POST['optn']!="DATE_OF_DISCONNECTION" || $_POST['optn']!="DATE_OF_CONNECTION"){

            $value=htmlspecialchars($_POST['optn']);
            $stmt="update TITASP.customer set $value = '".$new."' where lower(CUSTOMER_ID) = lower('".$CUSTOMER_ID."')";
            $stid=oci_parse($conn, $stmt);
            oci_execute($stid);
        }
        else if ($_POST['optn']=="DATE_OF_DISCONNECTION" || $_POST['optn']=="DATE_OF_CONNECTION"){
            $value=htmlspecialchars($_POST['optn']);
            $stmt="update TITASP.customer set $value = to_date('".$new."','DD.MM.YYYY') where lower(CUSTOMER_ID) = lower('".$CUSTOMER_ID."')";
            $stid=oci_parse($conn, $stmt);
            oci_execute($stid);
        }

        echo "Updated!\n";
        echo  "<a href=\"customer.php\">Go Back</a>";
    }

    if(isset($_POST['dlt'])){
        $CUSTOMER_ID=htmlspecialchars($_POST['CUSTOMER_ID']);
        $stmt="delete from TITASP.customer where lower(CUSTOMER_ID) = lower('".$CUSTOMER_ID."')";
        $stid=oci_parse($conn, $stmt);
        oci_execute($stid);

        echo "Deleted!\n";
        echo  "<a href=\"customer.php\">Go Back</a>";
    }


    if (isset($_POST['reltn'])){
            $CUSTOMER_ID=htmlspecialchars($_POST['CUSTOMER_ID']);
            $DEALER_ID=htmlspecialchars($_POST['DEALER_ID']);
        $conn=oci_connect("system","mM18061996","localhost/xe");
            $stmt2= "insert into TITASP.REGISTERED values (:DEALER_ID, :CUSTOMER_ID)";
            $stid2=oci_parse($conn,$stmt2);

            oci_bind_by_name($stid2, ':CUSTOMER_ID', $CUSTOMER_ID);
            oci_bind_by_name($stid2, ':DEALER_ID', $DEALER_ID);

            oci_execute($stid2);
        echo "Registered!\n";
        echo  "<a href=\"customer.php\">Go Back</a>";
    }
//////////////////////////////////////////////////////

    if (isset($_POST['inserts'])){

        $DEALER_ID=htmlspecialchars($_POST['DEALER_ID']);        $DEALER_PASSWORD=htmlspecialchars($_POST['DEALER_PASSWORD']);        $DEALER_USERNAME=htmlspecialchars($_POST['DEALER_USERNAME']);
        $DEALER_NAME=htmlspecialchars($_POST['DEALER_NAME']);
        $NID=htmlspecialchars($_POST['NID']);
        $DEALER_JOIN_DATE=htmlspecialchars(date('d.m.Y', strtotime($_POST['DEALER_JOIN_DATE'])));       
      
        $DEALER_WORKING_AREA=htmlspecialchars($_POST['DEALER_WORKING_AREA']);
        $ROAD_NO=htmlspecialchars($_POST['ROAD_NO']);
        $STREET_NO=htmlspecialchars($_POST['STREET_NO']);
        $HOUSE_NO=htmlspecialchars($_POST['HOUSE_NO']);

        $conn=oci_connect("system","mM18061996","localhost/xe");
        $stmt= "insert into TITASP.dealer values (:DEALER_ID,:DEALER_PASSWORD, :DEALER_USERNAME, :NID, :DEALER_NAME, TO_DATE('".$DEALER_JOIN_DATE."','DD.MM.YYYY'),:DEALER_WORKING_AREA, :ROAD_NO, :STREET_NO, :HOUSE_NO)";
        $stid=oci_parse($conn,$stmt);

        oci_bind_by_name($stid, ':DEALER_ID', $DEALER_ID);      
        oci_bind_by_name($stid, ':DEALER_PASSWORD', $DEALER_PASSWORD);        
        oci_bind_by_name($stid, ':DEALER_USERNAME', $DEALER_USERNAME);
        oci_bind_by_name($stid, ':DEALER_NAME', $DEALER_NAME);
        oci_bind_by_name($stid, ':NID', $NID);
        oci_bind_by_name($stid, ':ROAD_NO', $ROAD_NO);
        oci_bind_by_name($stid, ':STREET_NO', $STREET_NO);
        oci_bind_by_name($stid, ':HOUSE_NO', $HOUSE_NO);
        oci_bind_by_name($stid, ':DEALER_WORKING_AREA', $DEALER_WORKING_AREA);

        if (oci_execute($stid))

        { echo "Inserted!\n";
        echo  "<a href=\"customer.php\">Go Back</a>";}
else{         header("Location: http://localhost/titas/admin/insertion/customer/wrong.php");

    }
    
    }


    if (isset($_POST['insertb'])){

        $BILL_ID=htmlspecialchars($_POST['BILL_ID']);
        $BILLING_FINE=htmlspecialchars($_POST['BILLING_FINE']);
        $BILLING_FEES=htmlspecialchars($_POST['BILLING_FEES']);
        $CONNECTION_STATUS=htmlspecialchars($_POST['CONNECTION_STATUS']);
        $MONTH_WISE_DATE=htmlspecialchars(date('d.m.Y', strtotime($_POST['MONTH_WISE_DATE'])));       
      
        $TOTAL_PAID=htmlspecialchars($_POST['TOTAL_PAID']);
        $BILLING_TYPE=htmlspecialchars($_POST['BILLING_TYPE']);


        $conn=oci_connect("system","mM18061996","localhost/xe");
        $stmt= "insert into TITASP.billing values (:BILL_ID,:BILLING_FINE, :BILLING_FEES,:CONNECTION_STATUS, TO_DATE('".$MONTH_WISE_DATE."','DD.MM.YYYY'),:TOTAL_PAID, :BILLING_TYPE)";
        $stid=oci_parse($conn,$stmt);

        oci_bind_by_name($stid, ':BILL_ID', $BILL_ID);
        oci_bind_by_name($stid, ':BILLING_FINE', $BILLING_FINE);
        oci_bind_by_name($stid, ':BILLING_FEES', $BILLING_FEES);
        oci_bind_by_name($stid, ':CONNECTION_STATUS', $CONNECTION_STATUS);
        oci_bind_by_name($stid, ':TOTAL_PAID', $TOTAL_PAID);
        oci_bind_by_name($stid, ':BILLING_TYPE', $BILLING_TYPE);
//        oci_bind_by_name($stid, ':name', $name);
//        oci_bind_by_name($stid, ':gen', $gen);
//        oci_bind_by_name($stid, ':addr', $addr);
//        oci_bind_by_name($stid, ':mail', $mail);

        if (oci_execute($stid))

        { echo "Inserted!\n";
        echo  "<a href=\"customer.php\">Go Back</a>";}
else{         header("Location: http://localhost/titas/admin/insertion/customer/wrong.php");

    }
    
    }

    if(isset($_POST['dlts'])){
        $DEALER_ID=htmlspecialchars($_POST['DEALER_ID']);
        $stmt="delete from TITASP.dealer where lower(DEALER_ID) = lower('".$DEALER_ID."')";
        $stid=oci_parse($conn, $stmt);
        oci_execute($stid);

        echo "Deleted!\n";
        echo  "<a href=\"customer.php\">Go Back</a>";
    }

    if (isset($_POST['reltns'])){
            $CUSTOMER_ID=htmlspecialchars($_POST['CUSTOMER_ID']);
            $BILL_ID=htmlspecialchars($_POST['BILL_ID']);
        $conn=oci_connect("system","mM18061996","localhost/xe");
            $stmt2= "insert into TITASP.bill values (:BILL_ID, :CUSTOMER_ID)";
            $stid2=oci_parse($conn,$stmt2);

            oci_bind_by_name($stid2, ':CUSTOMER_ID', $CUSTOMER_ID);
            oci_bind_by_name($stid2, ':BILL_ID', $BILL_ID);

            oci_execute($stid2);
        echo "Assigned!\n";
        echo  "<a href=\"customer.php\">Go Back</a>";
    }

    if(isset($_POST['dltss'])){
        $BILL_ID=htmlspecialchars($_POST['BILL_ID']);
        $stmt="delete from TITASP.bill where lower(BILL_ID) = lower('".$BILL_ID."')";
        $stid=oci_parse($conn, $stmt);
        oci_execute($stid);
        $stm="delete from TITASP.billing where lower(BILL_ID) = lower('".$BILL_ID."')";
        $stid=oci_parse($conn, $stm);
        oci_execute($stid);        echo "Deleted!\n";
        echo  "<a href=\"customer.php\">Go Back</a>";
    }










?>