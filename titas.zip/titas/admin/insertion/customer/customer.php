<?php
    session_start();
    if($_SESSION['admin']==session_id())
        echo "<a href='../../../logout.php'><button id='btns'>Logout</button></a>";
    else
        header("location:../../../login.php");
?>

<!doctype html>
<html lang="en">
    <link href="astyle.css" rel="stylesheet">

    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TITAS GAS</title>
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="astyle.css">
    <style>
            body {
            background: url(images/167588163.jpg);
            background-repeat: repeat;
        }
.navbar-default{
    background: linear-gradient(to bottom,#27a1e8,#27cbe8,#27a1e8);
}
.navbar-default .navbar-nav>li>a {
    color: white;
}
.navbar-default .navbar-nav>li {
    border-bottom: 2px solid #27a1e8;
}
.navbar-default .navbar-nav>li:hover {
    border-bottom: 2px solid white;
}

.navbar-default .navbar-brand:hover {
background: #27cbe8;
}
    </style>
    </head>
    

    <body>


    
    <a href="../../list.php"><button id="btns">Home</button></a><br><br>
<h1>TITAS GAS CUSTOMER</h1>
   <div class="container-fluid">
       <div class="row">
           <div class="col-md-6">
    <button onclick="showEmp()">Show List of Customers</button><br><br>
    <script>
        function showEmp() {
            var x = document.getElementById('show');
            if (x.style.display === 'none') {
                x.style.display = 'block';
            } else {
                x.style.display = 'none';
            }
        }
    </script>

    <div style="display: none; " id="show">
        <?php
        $conn=oci_connect("system","mM18061996","localhost/xe");
        $stmt="select upper(customer_id) \"Customer ID\",initcap(customer_name) \"Customer Name\",initcap(customer_total_meter) \"Customer Meters\",date_of_connection \"Date of Connection\" ,date_of_disconnection \"Customer Disconnection Date\",road_no,street_no,house_no \"Address\" from titasp.customer e";
        $stid=oci_parse($conn,$stmt);
        oci_execute($stid);

        echo "<table border='1'>\n";
        $ncols = oci_num_fields($stid);
        echo "<tr>";
        for ($i = 1; $i <= $ncols; $i++) {
            $column_name  = oci_field_name($stid, $i);
            echo "<th>$column_name</th>";
        }
        echo "</tr>";
        while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
            echo "<tr>\n";
            foreach ($row as $item) {
                echo "    <td>" . ($item !== null ? htmlentities($item, ENT_QUOTES) : "&nbsp;") . "</td>\n";
            }
            echo "</tr>\n";
        }
        echo "</table>\n";
        echo "<br><br>";
        ?>
    </div>

    <button onclick="insertEmp()">Create a Customer</button><br><br>
    <script>
        function insertEmp() {
            var x = document.getElementById('insert');
            if (x.style.display === 'none') {
                x.style.display = 'block';
            } else {
                x.style.display = 'none';
            }
        }
    </script>

    <div style="display: none" id="insert">
        <form method="post" action="incustomer.php" enctype="multipart/form-data">
            <label>Customer ID</label>
            <input type="text" name="CUSTOMER_ID" required><br>

            <label>Customer Name</label>
            <input type="text" name="CUSTOMER_NAME"><br>

            <h4>Meter Info</h4>
            <label>Total Meters</label>
            <input type="text" name="CUSTOMER_TOTAL_METER"><br>
            <label>Date of Connection</label>
            <input type="date" name="DATE_OF_CONNECTION"><br>
            <label>Date of Disconnection</label>
            <input type="date" name="DATE_OF_DISCONNECTION"><br>                                        
            <h4>Personal Info</h4>

            <label>Customer UserName</label>
            <input type="text" name="CUSTOMER_USER_NAME"><br>

            <label>Road no</label>
            <input type="text" name="ROAD_NO"><br>
            <label>Street no</label>
            <input type="text" name="STREET_NO"><br>
            <label>House no</label>
            <input type="text" name="HOUSE_NO"><br>

                 <label>CUSTOMER PASSWORD</label>
            <input type="text" name="CUSTOMER_PASSWORD"><br>

     
            <input type="submit" name="insrt" value="Create customer">
        </form>
    </div>

    <button onclick="updateEmp()">Update Existing Customer</button><br><br>
    <script>
        function updateEmp() {
            var x = document.getElementById('update');
            if (x.style.display === 'none') {
                x.style.display = 'block';
            } else {
                x.style.display = 'none';
            }
        }
    </script>

    <div style="display: none; " id="update">
        <form method="post" action="incustomer.php" enctype="multipart/form-data">
            Customer ID:
            <input type="text" name="CUSTOMER_ID"><br>
            What do you want to update?
            <select name="optn">
                <option value="CUSTOMER_TOTAL_METER">Total Meters</option>
                <option value="DATE_OF_CONNECTION">Date Of connection</option>
                <option value="DATE_OF_DISCONNECTION">Date Of Disconnection</option>
            </select><br>
            Enter New Value:
            <input type="text" name="new"><br><br>
            <input type="submit" name="updt" value="Update customer">
        </form>
    </div>

    <button onclick="deleteEmp()">Delete a Customer</button><br><br>
    <script>
        function deleteEmp() {
            var x = document.getElementById('delete');
            if (x.style.display === 'none') {
                x.style.display = 'block';
            } else {
                x.style.display = 'none';
            }
        }
    </script>

   
    <div style="display: none" id="delete">
        <form method="post" action="incustomer.php" enctype="multipart/form-data">
            Customer ID:
            <input type="text" name="CUSTOMER_ID"><br><br>
            <input type="submit" name="dlt" value="Delete customer"><br><br>
        </form>
    </div>


    <button onclick="assignEmp()">Assign an Customer to a Dealer</button><br><br>
    <script>
        function assignEmp() {
            var x = document.getElementById('assign');
            if (x.style.display === 'none') {
                x.style.display = 'block';
            } else {
                x.style.display = 'none';
            }
        }
    </script>

    <div style="display: none" id="assign">
        <form method="post" action="incustomer.php" enctype="multipart/form-data">
            <label>Dealer ID</label>
            <input type="text" name="DEALER_ID"><br>
            <label>Customer ID</label>
            <input type="text" name="CUSTOMER_ID"><br>            <br>
            <input type="submit" name="reltn" value="Assign">
        </form>
    </div>
           </div>
           <div class="col-md-6">


    <button onclick="insertdeal()">Create a Dealer</button><br><br>
    <script>
        function insertdeal() {
            var x = document.getElementById('insert2');
            if (x.style.display === 'none') {
                x.style.display = 'block';
            } else {
                x.style.display = 'none';
            }
        }
    </script>

    <div style="display: none" id="insert2">
        <form method="post" action="incustomer.php" enctype="multipart/form-data">
            <label>Dealer ID</label>
            <input type="text" name="DEALER_ID" required><br>         
           <label>Dealer password</label>
            <input type="text" name="DEALER_PASSWORD" required><br>
            <label>Dealer username</label>
            <input type="text" name="DEALER_USERNAME" required><br>
            <label>NID</label>
            <input type="text" name="NID"><br>           
            <label>Dealer Name</label>
            <input type="text" name="DEALER_NAME"><br>

            <h4>Work info</h4>
            <label>Date of joining</label>
            <input type="date" name="DEALER_JOIN_DATE"><br>     
            <label>Dealer Working Area</label>
            <input type="text" name="DEALER_WORKING_AREA"><br>                                        
         
            <h4>Personal Info</h4>
            <label>Road no</label>
            <input type="text" name="ROAD_NO"><br>
            <label>Street no</label>
            <input type="text" name="STREET_NO"><br>
            <label>House no</label>
            <input type="text" name="HOUSE_NO"><br>

     
            <input type="submit" name="inserts" value="Create dealer">
        </form>
    </div>

    <button onclick="deletedeal()">Delete a Dealer</button><br><br>
    <script>
        function deletedeal() {
            var x = document.getElementById('delete2');
            if (x.style.display === 'none') {
                x.style.display = 'block';
            } else {
                x.style.display = 'none';
            }
        }
    </script>

   
    <div style="display: none" id="delete2">
        <form method="post" action="incustomer.php" enctype="multipart/form-data">
            Dealer ID:
            <input type="text" name="DEALER_ID"><br><br>
            <input type="submit" name="dlts" value="Delete dealer"><br><br>
        </form>
    </div>

<!--
    <button onclick="showmed()">Show Medical History of an Employee</button><br><br>
    <script>
        function showmed() {
            var x = document.getElementById('shwmd');
            if (x.style.display === 'none') {
                x.style.display = 'block';
            } else {
                x.style.display = 'none';
            }
        }
    </script>
-->

<!--
    <div style="display: none" id="shwmd">
        <form method="post" action="inemployee.php" enctype="multipart/form-data">
            Employee ID:
            <input type="text" name="eid"><br><br>
            <input type="submit" name="med" value="Show Medical History"><br><br>
        </form>
    </div>
-->

    <button onclick="insertbill()">Create a new Bill</button><br><br>
    <script>
        function insertbill() {
            var x = document.getElementById('insert3');
            if (x.style.display === 'none') {
                x.style.display = 'block';
            } else {
                x.style.display = 'none';
            }
        }
    </script>

    <div style="display: none" id="insert3">
        <form method="post" action="incustomer.php" enctype="multipart/form-data">
            <label>Bill ID</label>
            <input type="text" name="BILL_ID" required><br>
            <label>BILLING FINE</label>
            <input type="text" name="BILLING_FINE"><br>            <label>BILLING FEES</label>
            <input type="text" name="BILLING_FEES"><br>           
            <label>CONNECTION STATUS</label>
            <input type="text" name="CONNECTION_STATUS"><br>

            <label>DATE</label>
            <input type="date" name="MONTH_WISE_DATE"><br>     

            <label>Paid</label>
            <input type="text" name="TOTAL_PAID"><br>
            <label>BILLING TYPE</label>
            <input type="text" name="BILLING_TYPE"><br>
            <input type="submit" name="insertb" value="create billing">
        </form>
    </div>

   
   
    <button onclick="assignbill()">Assign Bill to Customer</button><br><br>
    <script>
        function assignbill() {
            var x = document.getElementById('assign2');
            if (x.style.display === 'none') {
                x.style.display = 'block';
            } else {
                x.style.display = 'none';
            }
        }
    </script>

    <div style="display: none" id="assign2">
        <form method="post" action="incustomer.php" enctype="multipart/form-data">
            <label>Bill ID</label>
            <input type="text" name="BILL_ID"><br>
            <label>Customer ID</label>
            <input type="text" name="CUSTOMER_ID"><br>            <br>
            <input type="submit" name="reltns" value="Assign bill">
        </form>
    </div>


    <button onclick="deletedbill()">Delete Bill</button><br><br>
    <script>
        function deletedbill() {
            var x = document.getElementById('delete3');
            if (x.style.display === 'none') {
                x.style.display = 'block';
            } else {
                x.style.display = 'none';
            }
        }
    </script>

   
    <div style="display: none" id="delete3">
        <form method="post" action="incustomer.php" enctype="multipart/form-data">
            Bill ID:
            <input type="text" name="BILL_ID"><br><br>
            <input type="submit" name="dltss" value="Delete bill"><br><br>
        </form>
    </div>
      
           </div>
       </div>
   </div>
    <script src="bootstrap-3.3.7-dist/js/jquery-3.2.1.min.js"></script>
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>
</html>
