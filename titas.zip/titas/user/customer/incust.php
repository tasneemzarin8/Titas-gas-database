<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TITAS</title>
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
            body {
            background: url(images/167588163.jpg);
            background-repeat: repeat;
        }
.navbar-default{
    background: linear-gradient(to bottom,#27a1e8,#27cbe8,#27a1e8);
}
.navbar-default .navbar-nav>li>a {
    color: white;
}
.navbar-default .navbar-nav>li {
    border-bottom: 2px solid #27a1e8;
}
.navbar-default .navbar-nav>li:hover {
    border-bottom: 2px solid white;
}

.navbar-default .navbar-brand:hover {
background: #27cbe8;
}        
    </style>
</head>
<body>
   <nav class="navbar navbar-default">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
                <a class="navbar-brand" href="http://localhost/titas/index.html"><img src="images/titas-gas-logo.png" class="img-responsive" style="margin-top: -15px; width: 100px; height: 75px"></a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  

                </ul>
                <form class="navbar-form navbar-left">
                </form>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="http://localhost/titas/login.php">Admin</a></li>
        <li><a href="http://localhost/titas/custlogin/customer/customer.php">Customer Login</a></li>
                    <li><a href="http://localhost/titas/user/customer/customer.php">Search</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

   <?php
    $conn=oci_connect("system","mM18061996","localhost/xe");


    if(isset($_POST['Search'])) {
        $conn=oci_connect("system","mM18061996","localhost/xe");
        $srchq = htmlspecialchars($_POST['new']);
        $srchq = preg_replace("#[^0-9a-z]#i", "", $srchq);

        $nme="select upper(customer_id) \"Customer ID\",initcap(customer_name) \"Customer Name\",initcap(customer_total_meter) \"Customer Meters\",date_of_connection \"Date of Connection\" ,date_of_disconnection \"Customer Disconnection Date\",road_no,street_no,house_no \"Address\" from titasp.customer where lower( \"CUSTOMER_ID\") like lower('%$srchq%') ";

        $pss="select upper(EMPLOYEE_ID)\"EMPLOYEE ID	\",initcap(EMPLOYEE_NAME) \"EMPLOYEE NAME\",initcap(EMAIL_ID) \"EMAIL ID\",DATE_OF_JOIN \"JOIN DATE\",DATE_OF_RETAIRMENT \"DATE OF RETAIRMENT\",AGE \"AGE\",EMP_SCHOOL \"SCHOOL\",house_no \"House no\" from titasp.employee where lower( \"EMPLOYEE_ID\") like lower('%$srchq%') ";
        $ptt="select upper(DEALER_ID)\"DEALER ID	\",initcap(NID) \"NID\",initcap(DEALER_NAME) \"DEALER NAME\",DEALER_JOIN_DATE \"DEALER JOIN DATE\",DEALER_WORKING_AREA \"DEALER WORKING AREA\",road_no \"Road no\",street_no \"Street no\",house_no \"House no\" from titasp.dealer where lower( \"DEALER_ID\") like lower('%$srchq%') ";
        $wwr="select * from titasp.project where lower( \"PROJECT_CODE\") like lower('%$srchq%') ";



        switch($_POST['show']){
            case "CUSTOMER_ID"        :  $query=$nme; break;
            case "DEALER_ID"     :   $query=$ptt; break;
            case "EMPLOYEE_ID"     :   $query=$pss; break;
            case "PROJECT_CODE"     :   $query=$wwr; break;

        }

        $stid1 = oci_parse($conn, $query);
        if (oci_execute($stid1)){
        echo "<table border='1'>\n";

        echo "<tr>";
        $coll = oci_num_fields($stid1);
        for ($i = 1; $i <= $coll; $i++) {
            $column_name = oci_field_name($stid1, $i);
            echo "<th>$column_name</th>";
        }
        echo "</tr>";
        while ($row = oci_fetch_array($stid1, OCI_ASSOC + OCI_RETURN_NULLS)) {
            echo "<tr>\n";
            foreach ($row as $item) {
                echo "    <td>" . ($item !== null ? htmlentities($item, ENT_QUOTES) : "&nbsp;") . "</td>\n";
            }
            echo "</tr>\n";
        }
        echo "</table>\n";
    }
    }
else{
      header("Location: http://localhost/titas/admin/insertion/customer/wrong.php");
}

   
?>

    <script src="bootstrap-3.3.7-dist/js/jquery-3.2.1.min.js"></script>
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>
</html>