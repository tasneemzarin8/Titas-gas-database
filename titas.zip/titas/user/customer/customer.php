<!doctype html>
<html lang="en">
    <link href="../style.css" rel="stylesheet">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap-theme.min.css">  
    <link rel="stylesheet" href="style.css">
    
    <title>Passenger</title>
    <style>
            body {
            background: url(images/167588163.jpg);
            background-repeat: repeat;
        }
.navbar-default{
    background: linear-gradient(to bottom,#27a1e8,#27cbe8,#27a1e8);
}
.navbar-default .navbar-nav>li>a {
    color: white;
}
.navbar-default .navbar-nav>li {
    border-bottom: 2px solid #27a1e8;
}
.navbar-default .navbar-nav>li:hover {
    border-bottom: 2px solid white;
}

.navbar-default .navbar-brand:hover {
background: #27cbe8;
}
    </style>
</head>
<body>
   <nav class="navbar navbar-default">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
                <a class="navbar-brand" href="http://localhost/titas/index.html"><img src="images/titas-gas-logo.png" class="img-responsive" style="margin-top: -15px; width: 100px; height: 75px"></a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  

                </ul>
                <form class="navbar-form navbar-left">
                </form>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="http://localhost/titas/login.php">Admin</a></li>
        <li><a href="http://localhost/titas/custlogin/customer/customer.php">Customer Login</a></li>
                    <li><a href="http://localhost/titas/user/customer/customer.php">Search</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <h1>Titas Gas</h1>
    <a href="http://localhost/titas/index.html"><button id="btns">Home</button></a><br><br>

    <div class="src">
        <form method="post" action="incust.php" enctype="multipart/form-data">
            <label>Search By Category</label>
            <select class="src" name="show">
                <option value="CUSTOMER_ID">CUSTOMER ID</option>
                <option value="DEALER_ID">DEALER ID</option>
                <option value="EMPLOYEE_ID">EMPLOYEE ID</option>
                <option value="PROJECT_CODE">PROJECT CODE</option>

<!--
                <option value="nat">Nationality</option>
                <option value="age">Age Less than</option>
                <option value="age1">Age Greater than</option>
                <option value="type">Passport Type</option>
                <option value="tick">Ticket No.</option>
                <option value="bag">Baggage ID.</option>
                <option value="gate">Gate No.</option>
-->
            </select>
            <input class="src" type="text" name="new" placeholder='Search'>
            <input class="src" type="submit" name="Search">
        </form>
    </div>

     <script src="bootstrap-3.3.7-dist/js/jquery-3.2.1.min.js"></script>
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script> 
</body>
</html>