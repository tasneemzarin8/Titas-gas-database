<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TITAS GAS</title>
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="style.css">
   <style>

    td{
        background:#334056;
        border: 1px solid black;
        padding: 30px;
    }
       body{
           background: url(images/31895327_378324199350181_3103637419283447808_n.png);
           color: white;
       }




    </style></head>
    

<body>
  <!--Nav bar starts-->
    <!--Nav bar starts-->
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
                <a class="navbar-brand" href="http://localhost/titas/index.html"><img src="images/titas-gas-logo.png" class="img-responsive" style="margin-top: -15px; width: 100px; height: 75px"></a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  

                </ul>
                <form class="navbar-form navbar-left">
                </form>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="http://localhost/titas/login.php">Admin</a></li>
        <li><a href="http://localhost/titas/custlogin/customer/customer.php">Customer Login</a></li>
                    <li><a href="http://localhost/titas/user/customer/customer.php">Search</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
<h1 style="text-align:center;color: #2156dd">MACHINE STATUS</h1>
<?php

$username = 'SYSTEM';
$password = 'mM18061996';
$connection_string = 'localhost/xe';
$connection = oci_connect($username,$password,$connection_string);


if($connection)
	echo " ";
else
{
	echo "Connection failed";
    $err = oci_error();
	trigger_error(htmlentities($err['message'], ENT_QUOTES), E_USER_ERROR);	
}
?>




<table style="margin: 0 auto; border: 2px solid blue;margin-top:40px"><tr style="border: 2px solid blue;color:blue">
<td style="color:blue">FIELD NAME</td> 
<td style="color:blue">MACHINE TYPE</td> 
<td style="color:blue">STATUS</td> 
 

<?php  
	$stid = oci_parse($connection, 'SELECT * FROM TITASP.MACHINE_STAT');
	oci_execute($stid);
	while (($row = oci_fetch_array($stid, OCI_BOTH)) != false) {
?>




<!--Nav bar ends-->
  <tr>
	<td><?php echo $row[0] ?></td>
	<td><?php echo $row[1] ?></td>
	<td><?php echo $row[2] ?></td>

	
  </tr>
<?php
}
oci_free_statement($stid);
oci_close($connection);
?>
</table>	


    
 <script src="bootstrap-3.3.7-dist/js/jquery-3.2.1.min.js"></script>   
 <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script> 
    </body>
</html>