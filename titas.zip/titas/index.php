<!--html:5 tab for this install skeleton/emet plugin-->
     <?php

    if (isset($_SESSION['admin']))
        header("Location: admin/list.php");

    if (isset($_POST['Submit'])){
        $usr=$_POST['usr'];
        $pass=$_POST['pass'];

        if($usr == 'admin' and $pass == 'admin123') {
            session_start();
            $_SESSION['admin']=session_id();
            header("location:admin/list.php");
        }

        else {
            echo "<p style='text-align: center; font: bold 20px Comic Sans MS; color: white'>wrong username or password</p>";
        }
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!--   take meta from get bootsrap.com basic templates-->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TITAS GAS</title>
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="astyle.css">
    <!--     must maintain this sequence-->
    <style>
        body {
            background: url(images/31895327_378324199350181_3103637419283447808_n.png);
            background-repeat: repeat;
        }

         .btn{
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: linear-gradient(to bottom right, blue, skyblue, white);
            color: darkblue;
            margin: 30px;
        }
        .btn:hover{
           background: darkblue;
           color: white;
        }
div.gallery {
    border: 1px solid black;
}

div.gallery:hover {
    border: 10px solid black;
}

div.gallery img {
    width: 100%;
    height: auto;
}

div.desc {
    padding: 15px;
    text-align: center;
    background: #334056;
    color: white;
    font-family: cursive;
}

* {
    box-sizing: border-box;
}

.responsive {
    padding: 0 6px;
    float: left;
    width: 24.99999%;
}
*{margin:0px; padding:0px; font-family:Helvetica, Arial, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
    width: 30%;
    padding: 12px 20px;
    margin: 8px 26px;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
	font-size:16px;
}

/* Set a style for all buttons */
#buttone {
    background-color: #334056;
    color: white;
    padding: 14px 20px;
    margin: 8px 26px;
    border: none;
    cursor: pointer;
    width: 30%;
	font-size:20px;
}
#buttone:hover {
    opacity: 0.8;
}

/* Center the image and position the close button */
.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
}
.avatar {
    width: 200px;
	height:200px;
    border-radius: 50%;
}

/* The Modal (background) */
.modal {
	display:none;
    position: fixed;
    z-index: 100;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0,0,0,0.8);
}

/* Modal Content Box */
.modal-content {
    background: url(images/31895327_378324199350181_3103637419283447808_n.png);
    margin: 4% auto 15% auto;
    border: 1px solid #888;
    width: 40%; 
	padding-bottom: 30px;
    font-family: cursive;
}

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
}
.close:hover,.close:focus {
    color: red;
    cursor: pointer;
}

/* Add Zoom Animation */
.animate {
    animation: zoom 0.6s
}
@keyframes zoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}
@media only screen and (max-width: 700px) {
    .responsive {
        width: 49.99999%;
        margin: 6px 0;
    }
}

@media only screen and (max-width: 500px) {
    .responsive {
        width: 100%;
    }
}

.clearfix:after {
    content: "";
    display: table;
    clear: both;
}    </style>

</head>

<body>
    <!--Nav bar starts-->
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false" id="btnss">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
                <a class="navbar-brand" href="http://localhost/titas/index.html"><img src="images/titas-gas-logo.png" class="img-responsive" style="margin-top: -15px; width: 100px; height: 75px"></a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  

                </ul>
                <form class="navbar-form navbar-left">
                </form>
                <ul class="nav navbar-nav navbar-right">
                    <li><a><button onclick="document.getElementById('modal-wrapper').style.display='block'" >Admin</button></a></li>
        <li><a href="http://localhost/titas/custlogin/customer/customer.php"><button>Customer Login</button></a></li>
                    <li><a href="http://localhost/titas/user/customer/customer.php"><button>Search</button></a></li>
                    <li><a href="#abtus"><button>About Us</button></a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <!--Nav bar ends-->
    <!--Carousel Starts-->
    <div class="container-fluid" style="width: 100%; margin-top: -22px; background: black">
        <div id="myCarousel" class="row">

            <div>
<!-- The video -->

<video autoplay muted loop id="myVideo">
  <source src="images/video-1525369051.mp4" type="video/mp4">
  Your browser does not support HTML5 video.
</video>

<div class="content" style="margin-top: -600px; text-align: center">
  <h2 style="font-size: 50px; font-family: cursive">
Titas Gas Transmission AND Distribution Company Limited</h2>
</div>


            </div>

        </div>
        <!--Carousel Ends-->
<div id="abtus">
<h1 style="text-align: left;margin-top: 500px;margin-bottom: 30px"><img src="images/titas-gas-logo.png" style="width: 100px;height: 100px">&nbsp;About US</h1>
<p style="color: white">The discovery of a huge gas field on the bank of the Titas River in Bhramanbaria in 1962 created a new horizon for the utilization of natural gas. Being established on November 20,1964 Titas Gas Transmission and Distribution Company Limited (TGTDCL) has completed 50 years of its operation. The company began its commercial operation with the commissioning of gas supply to Siddhirganj Thermal Power Station on April 28, 1968 after construction of 14 inch dia 58 mile long Titas-Demra gas pipeline by the then East Pakistan Industrial Development Corporation. As a progressive national organization, it has earned the glory of being a trustworthy one for the people by means of the quality of service delivery.</p><br><br>
    
</div>        
        
        
    </div>
<h1 style="text-align: center;margin-top: 50px;margin-bottom: 30px">Company Statistics</h1>

<div class="responsive">
  <div class="gallery">
    <a target="_blank" href="http://localhost/titas/view/area_deal_inac.php">
      <img src="images/inac.png" alt="INACTIVE CUSTOMERS" width="300" height="200">
    </a>
    <div class="desc">DEALERS WITH INACTIVE CUSTOMERS</div>
  </div>
</div>
<div class="responsive">
  <div class="gallery">
    <a target="_blank" href="http://localhost/titas/view/ac_feedback.php">
      <img src="images/feed.png" alt="Northern Lights" width="600" height="400">
    </a>
    <div class="desc">SATISFIED CUSTOMER <br>FEEDBACK</div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank" href="http://localhost/titas/view/area_deal_ac.php">
      <img src="images/ac.png" alt="Forest" width="600" height="400">
    </a>
    <div class="desc">DEALERS WITH ACTIVE <br>CUSTOMERS</div>
  </div>
</div>



<div class="responsive">
  <div class="gallery">
    <a target="_blank" href="http://localhost/titas/view/machine_stat.php">
      <img src="images/mac.png" alt="Mountains" width="600" height="400">
    </a>
    <div class="desc">MACHINE STATUS<br><br></div>
  </div>
</div>

<div class="clearfix"></div>
<!--modal-------------------------------------->
<div id="modal-wrapper" class="modal">
  
  <form  method="post" action="" enctype="multipart/form-data" class="modal-content animate" action="">
  
     
    <div class="imgcontainer">
      <span onclick="document.getElementById('modal-wrapper').style.display='none'" class="close" title="Close PopUp">&times;</span>
      <img src="images/user.png" alt="Avatar" class="avatar">
      <h1 style="text-align:center">Admin Login</h1>
    </div>

    <div class="container">
                <label style="color:white">Username</label><br>
                <input type="text" name="usr"><br><br>
                <label style="color:white">Password</label><br>
                <input type="password" name="pass"><br><br>
                <input type="submit" name="Submit" value="LogIn" id="buttone">

    </div>
    
  </form>
  
</div>
<!--
        <div class="login" style="text-align:center">
            <form method="post" action="" enctype="multipart/form-data">
                <label>Username</label>
                <input type="text" name="usr"><br><br>
                <label>Password</label>
                <input type="password" name="pass"><br><br>
                <input type="submit" name="Submit" value="LogIn">
            </form>
        </div>
-->
    
<!--
    <div style="text-align:center; margin-top: 150px">
        <a href="http://localhost/s/branch.php#"><button class="btn">BRANCH</button></a>
        <a href="http://localhost/s/ADDRESS.php#"><button class="btn">ADDRESS</button></a>
        <a href="http://localhost/s/DEPARTMENT.php#"><button class="btn">DEPARTMENT</button></a><br>

        <a href="http://localhost/s/DEALER.php#"><button class="btn">DEALER</button></a>
        <a href="http://localhost/s/customer.php#"><button class="btn">CUSTOMER</button></a>
        <a href="http://localhost/s/BILLING.php#"><button class="btn">BILLING</button></a><br>

        <a href="http://localhost/s/employee.php#"><button class="btn">EMPLOYEE</button></a>
        <a href="http://localhost/s/EDUCATION.php#"><button class="btn">EDUCATION</button></a>
        <a href="http://localhost/s/PAYROLL.php#"><button class="btn">PAYROLL</button></a><br>

        <a href="http://localhost/s/DEPDETAILS.php#"><button class="btn">DEPENDENT DETAILS</button></a>
        <a href="http://localhost/s/LOAN.php#"><button class="btn">LOAN</button></a>
        <a href="http://localhost/s/WORKER.php#"><button class="btn">WORKER</button></a><br>

        <a href="http://localhost/s/PFIELD.php#"><button class="btn">PRODUCTION FIELD</button></a>
        <a href="http://localhost/s/DRIVER.php#"><button class="btn">DRIVER</button></a>
        <a href="http://localhost/s/REPAIR.php#"><button class="btn">REPAIRANCE</button></a><br>
        <a href="http://localhost/s/MACHINE.php#"><button class="btn">MACHINERIES</button></a>
        <a href="http://localhost/s/VEHICLES.php#"><button class="btn">VEHICES</button></a>
        <a href="http://localhost/s/STOCK.php#"><button class="btn">STOCK DETAILS</button></a><br>

        <a href="http://localhost/s/WELFARE.php#"><button class="btn">WELFARE</button></a>
        <a href="http://localhost/s/SCHOOL.php#"><button class="btn">SCHOOL</button></a>
        <a href="http://localhost/s/HOSPITAL.php#"><button class="btn">HOSPITAL</button></a><br>
        
        <a href="http://localhost/s/FUND.php#"><button class="btn">FUND</button></a>
        <a href="http://localhost/s/employee.php#"><button class="btn">METER INFO</button></a>
        <a href="http://localhost/s/PROJECT.php#"><button  class="btn">PROJECT</button></a><br>

    </div>
-->
<script>
// If user clicks anywhere outside of the modal, Modal will close

var modal = document.getElementById('modal-wrapper');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
    <script src="bootstrap-3.3.7-dist/js/jquery-3.2.1.min.js"></script>
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>

</html>